"""One-Click Incident Report — shared builder for the executive summary page
and the downloadable PDF.

build_report() compiles everything about a case into a single plain dict so
the HTML template and the PDF renderer stay in sync.
"""

import html
from io import BytesIO

from django.utils import timezone

from ..models import Evidence, Finding, TimelineEvent

SEVERITY_ORDER = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}

SECTIONS = [
    "Cover sheet",
    "Executive summary",
    "Key findings",
    "Attack timeline",
    "Evidence register",
    "Chain of custody",
    "Sign-off",
]


def _fmt(value):
    return html.escape(str(value)) if value is not None else ""


def _severity_rank(severity):
    return SEVERITY_ORDER.get(severity, -1)


def build_report(investigation):
    """Compile timeline, evidence, findings and custody into one dict."""
    from .integrity import verify_investigation

    events = list(
        investigation.timeline_events.select_related("evidence").order_by("occurred_at")
    )
    findings = sorted(investigation.findings.all(), key=lambda f: -_severity_rank(f.severity))
    evidence = list(investigation.evidence.all().order_by("uploaded_at"))
    integrity = verify_investigation(investigation)

    high_risk = sum(1 for f in findings if _severity_rank(f.severity) >= 3)
    narrative = _narrative(investigation, events, findings, evidence, integrity)

    return {
        "case_number": investigation.case_number,
        "title": investigation.title,
        "description": investigation.description,
        "status": investigation.get_status_display(),
        "status_code": investigation.status,
        "lead": investigation.created_by.username if investigation.created_by else "system",
        "opened_at": investigation.created_at,
        "updated_at": investigation.updated_at,
        "generated_at": timezone.now(),
        "filename": f"{investigation.case_number}-incident-report.pdf",
        "sections": SECTIONS,
        "stats": {
            "evidence": len(evidence),
            "events": len(events),
            "findings": len(findings),
            "high_risk": high_risk,
            "chain_blocks": integrity["chain"].get("blocks", 0),
        },
        "narrative": narrative,
        "findings": [
            {
                "id": str(f.pk),
                "title": f.title,
                "severity": f.severity,
                "confidence": f.confidence,
                "category": f.get_category_display(),
                "category_code": f.category,
                "mitre": f.mitre_technique or "—",
                "status": f.get_status_display(),
                "summary": f.summary,
                "explanation": f.explanation,
                "evidence_count": f.evidence_links.count(),
                "created_at": f.created_at,
                "generated_by": f.generated_by,
            }
            for f in findings
        ],
        "events": [
            {
                "occurred_at": e.occurred_at,
                "title": e.title,
                "description": e.description,
                "severity": e.severity,
                "actor": e.actor or "—",
                "source_ip": e.source_ip or "—",
                "generated_by": e.generated_by,
                "evidence": e.evidence.title if e.evidence else "—",
            }
            for e in events
        ],
        "evidence": [
            {
                "id": str(e.pk),
                "title": e.title,
                "type": e.get_evidence_type_display(),
                "type_code": e.evidence_type,
                "sha256": e.sha256 or "not fingerprinted",
                "source": e.source or "—",
                "uploaded_at": e.uploaded_at,
                "uploaded_by": e.uploaded_by.username if e.uploaded_by else "—",
                "events": e.parsed_summary.get("event_count", 0) if isinstance(e.parsed_summary, dict) else 0,
            }
            for e in evidence
        ],
        "integrity": {
            "valid": integrity["valid"],
            "blocks": integrity["chain"].get("blocks", 0),
            "tip": integrity["chain"].get("tip") or investigation.ledger_tip or "—",
            "checked_at": integrity["checked_at"],
            "tampered": integrity["tampered_objects"],
        },
    }


def _narrative(investigation, events, findings, evidence, integrity):
    stored = investigation.analysis_report or {}
    if stored.get("narrative"):
        return stored["narrative"]

    lines = [
        f"Investigation {investigation.case_number}: {investigation.title}. "
        f"{len(evidence)} evidence item(s), {len(events)} timeline event(s), {len(findings)} finding(s)."
    ]
    if events:
        lines.append(
            f"Recorded activity spans {events[0].occurred_at:%Y-%m-%d %H:%M} UTC to "
            f"{events[-1].occurred_at:%Y-%m-%d %H:%M} UTC."
        )
    if findings:
        top = findings[0]
        lines.append(
            f"Most severe conclusion: '{top.title}' ({top.severity}, confidence {top.confidence:.0%}) — {top.summary}"
        )
    else:
        lines.append(
            "No confirmed attack patterns yet — this report reflects the activity recorded so far. "
            "Run AI analysis from the case page to generate findings."
        )
    lines.append(
        "Chain of custody: "
        + ("integrity chain VERIFIED — every evidence and conclusion fingerprint checks out."
           if integrity["valid"] else
           "integrity chain FAILED verification — see the chain-of-custody section below.")
    )
    return " ".join(lines)



# --------------------------------------------------------------------- PDF
# Pure-Python PDF writer — no third-party dependencies (works on any
# machine with plain Python, including 3.14+, nothing to pip install).

_PDF_MAP = {
    "\u2014": "-", "\u2013": "-", "\u2019": "'", "\u2018": "'",
    "\u201c": '"', "\u201d": '"', "\u2026": "...", "\u2192": "->",
    "\u2190": "<-", "\u00b7": "-", "\u2022": "*", "\u00a0": " ",
    "\u2011": "-", "\u2212": "-",
}

_GOLD = (0.72, 0.57, 0.16)
_GOLD_SOFT = (0.95, 0.89, 0.70)
_INK = (0.11, 0.11, 0.13)
_GREY = (0.42, 0.42, 0.47)
_RED = (0.76, 0.23, 0.17)
_ROW_ALT = (0.975, 0.965, 0.93)
_LINE = (0.84, 0.82, 0.76)
_WHITE = (1, 1, 1)


def _pdf_clean(text):
    s = str(text)
    for bad, good in _PDF_MAP.items():
        s = s.replace(bad, good)
    return s.encode("cp1252", "replace").decode("cp1252")


def _pdf_esc(text):
    return _pdf_clean(text).replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")


def _text_w(text, size, bold=False):
    return len(text) * size * (0.53 if bold else 0.50)


def _pdf_wrap(text, width, size, bold=False):
    """Word-wrap; hard-breaks words longer than the column (hashes)."""
    words = _pdf_clean(text).split()
    lines, cur = [], ""
    for word in words:
        while _text_w(word, size, bold) > width:
            cut = max(1, int(width / (size * (0.53 if bold else 0.50))))
            if cur:
                lines.append(cur)
                cur = ""
            lines.append(word[:cut])
            word = word[cut:]
        trial = word if not cur else cur + " " + word
        if _text_w(trial, size, bold) <= width:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]


class _PdfDoc:
    """Minimal A4 PDF writer: text, rules, tables, page breaks, footer."""

    W, H = 595.28, 841.89          # A4 in points
    ML, MR, MT, MB = 52, 52, 58, 54

    def __init__(self, footer_left=""):
        self.pages = []
        self.ops = []
        self.y = self.H - self.MT
        self.footer_left = footer_left

    # ---------------------------------------------------------- primitives
    def _rgb(self, color, stroke=False):
        op = "RG" if stroke else "rg"
        self.ops.append(f"{color[0]:.3f} {color[1]:.3f} {color[2]:.3f} {op}")

    def _text(self, x, y, text, size=9.5, bold=False, color=_INK):
        font = "F2" if bold else "F1"
        self._rgb(color)
        self.ops.append(
            f"BT /{font} {size:.1f} Tf 1 0 0 1 {x:.1f} {y:.1f} Tm ({_pdf_esc(text)}) Tj ET"
        )

    def _rect(self, x, y, w, h, color):
        self._rgb(color)
        self.ops.append(f"{x:.1f} {y:.1f} {w:.1f} {h:.1f} re f")

    def _rule(self, x1, y, x2, color=_LINE, width=0.7):
        self._rgb(color, stroke=True)
        self.ops.append(f"{width:.1f} w {x1:.1f} {y:.1f} m {x2:.1f} {y:.1f} l S")

    def _vrule(self, x, y1, y2, color=_LINE, width=0.5):
        self._rgb(color, stroke=True)
        self.ops.append(f"{width:.1f} w {x:.1f} {y1:.1f} m {x:.1f} {y2:.1f} l S")

    def _flush(self):
        self.pages.append("\n".join(self.ops))
        self.ops = []

    def _new_page(self):
        self._flush()
        self.y = self.H - self.MT

    def space(self, h):
        self.y -= h

    def ensure(self, h):
        if self.y - h < self.MB + 24:
            self._new_page()

    # -------------------------------------------------------------- blocks
    def title_block(self, report):
        self._rect(0, self.H - 118, self.W, 118, (0.10, 0.07, 0.16))
        self._rect(0, self.H - 122, self.W, 4, _GOLD)
        cx = self.W / 2
        self._text(cx - 92, self.H - 40, "TRACE-X  .  DIGITAL FORENSICS", 9, True, _GOLD_SOFT)
        self._text(cx - 108, self.H - 68, "INCIDENT INVESTIGATION REPORT", 17, True, _WHITE)
        self._text(
            cx - 90, self.H - 90,
            f"Case {report['case_number']}  -  {report['title']}", 10, False, _GOLD_SOFT,
        )
        self._text(cx - 78, self.H - 108, "CONFIDENTIAL  .  FOR AUTHORISED PERSONNEL ONLY", 8, True, (1, 0.45, 0.4))
        self.y = self.H - 146

    def heading(self, number, text):
        self.ensure(40)
        self.space(10)
        self._text(self.ML, self.y, f"{number}. {text}", 12.5, True, _INK)
        self.y -= 6
        self._rule(self.ML, self.y, self.W - self.MR, _GOLD, 1.1)
        self.y -= 12

    def para(self, text, size=9.5, color=_INK, bold=False, indent=0):
        width = self.W - self.ML - self.MR - indent
        for line in _pdf_wrap(text, width, size, bold):
            self.ensure(size + 5)
            self._text(self.ML + indent, self.y, line, size, bold, color)
            self.y -= size + 4.5
        self.y -= 3

    def kv_grid(self, pairs, cols=2):
        """pairs = [(label, value), ...] laid out in a bordered grid."""
        col_w = (self.W - self.ML - self.MR) / cols
        rows = (len(pairs) + cols - 1) // cols
        row_h = 34
        self.ensure(rows * row_h + 6)
        top = self.y
        x0 = self.ML
        total_w = col_w * cols
        self._rect(x0, top - rows * row_h, total_w, rows * row_h, _WHITE)
        self._rule(x0, top, x0 + total_w, _GOLD, 0.9)
        self._rule(x0, top - rows * row_h, x0 + total_w, _GOLD, 0.9)
        for r in range(rows + 1):
            self._rule(x0, top - r * row_h, x0 + total_w, _LINE, 0.5)
        for c in range(cols + 1):
            self._vrule(x0 + c * col_w, top - rows * row_h, top, _LINE, 0.5)
        for idx, (label, value) in enumerate(pairs):
            r, c = divmod(idx, cols)
            cx = x0 + c * col_w + 9
            cy = top - r * row_h
            self._text(cx, cy - 13, _pdf_clean(label).upper(), 7, True, _GREY)
            for i, line in enumerate(_pdf_wrap(value, col_w - 18, 10, True)[:2]):
                self._text(cx, cy - 27 - i * 11, line, 10, True, _INK)
        self.y = top - rows * row_h - 12

    def table(self, headers, rows, widths, size=8.2):
        x0 = self.ML
        pad = 5
        leading = size + 3.5

        def draw_header():
            self.ensure(leading + 12)
            h = leading + 6
            self._rect(x0, self.y - h, sum(widths), h, _GOLD_SOFT)
            cx = x0
            for head, w in zip(headers, widths):
                self._text(cx + pad, self.y - leading + 1, head, size, True, _INK)
                cx += w
            self.y -= h
            self._rule(x0, self.y, x0 + sum(widths), _GOLD, 0.8)

        draw_header()
        for ridx, row in enumerate(rows):
            cells = [_pdf_wrap(cell, w - 2 * pad, size) for cell, w in zip(row, widths)]
            h = max(len(c) for c in cells) * leading + 8
            if self.y - h < self.MB + 24:
                self._new_page()
                draw_header()
            if ridx % 2 == 1:
                self._rect(x0, self.y - h, sum(widths), h, _ROW_ALT)
            cx = x0
            for lines, w in zip(cells, widths):
                for i, line in enumerate(lines):
                    self._text(cx + pad, self.y - leading - i * leading + 4, line, size, False, _INK)
                cx += w
            self.y -= h
            self._rule(x0, self.y, x0 + sum(widths), _LINE, 0.4)
        self.y -= 10

    def sign_lines(self, labels):
        self.ensure(70)
        col_w = (self.W - self.ML - self.MR) / len(labels)
        for i, label in enumerate(labels):
            x = self.ML + i * col_w
            self._text(x, self.y, label, 8, False, _GREY)
            self._rule(x, self.y - 42, x + col_w - 28, _GREY, 0.6)
        self.y -= 64

    # ---------------------------------------------------------------- build
    def build(self, footer_left=""):
        self._flush()
        page_count = len(self.pages)
        objects = []

        def add(body):
            objects.append(body)
            return len(objects)

        catalog_id = add("")            # 1
        pages_id = add("")              # 2
        font1_id = add(
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>"
        )
        font2_id = add(
            "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>"
        )

        page_ids = []
        for i, stream in enumerate(self.pages):
            footer_y = 36
            extra = [
                f"0.72 0.57 0.16 RG 0.7 w {self.ML} 46 m {self.W - self.MR} 46 l S",
                f"BT /F1 7 Tf 0.42 0.42 0.47 rg 1 0 0 1 {self.ML} {footer_y} Tm ({_pdf_esc(footer_left)}) Tj ET",
                f"BT /F1 7 Tf 0.42 0.42 0.47 rg 1 0 0 1 {self.W - self.MR - 58} {footer_y} Tm (Page {i + 1} of {page_count}) Tj ET",
            ]
            full = stream + "\n" + "\n".join(extra)
            data = full.encode("cp1252", "replace")
            content_id = add(f"<< /Length {len(data)} >>\nstream\n".encode("latin-1") + data + b"\nendstream")
            page_id = add(
                f"<< /Type /Page /Parent {pages_id} 0 R /MediaBox [0 0 {self.W:.0f} {self.H:.0f}] "
                f"/Resources << /Font << /F1 {font1_id} 0 R /F2 {font2_id} 0 R >> >> "
                f"/Contents {content_id} 0 R >>"
            )
            page_ids.append(page_id)

        kids = " ".join(f"{pid} 0 R" for pid in page_ids)
        objects[catalog_id - 1] = f"<< /Type /Catalog /Pages {pages_id} 0 R >>"
        objects[pages_id - 1] = f"<< /Type /Pages /Kids [{kids}] /Count {len(page_ids)} >>"

        out = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
        offsets = [0]
        for idx, obj in enumerate(objects, start=1):
            offsets.append(len(out))
            if isinstance(obj, bytes):
                out += f"{idx} 0 obj\n".encode("latin-1") + obj + b"\nendobj\n"
            else:
                out += f"{idx} 0 obj\n{obj}\nendobj\n".encode("cp1252", "replace")
        xref_pos = len(out)
        out += f"xref\n0 {len(objects) + 1}\n".encode("latin-1")
        out += b"0000000000 65535 f \n"
        for off in offsets[1:]:
            out += f"{off:010d} 00000 n \n".encode("latin-1")
        out += (
            f"trailer\n<< /Size {len(objects) + 1} /Root {catalog_id} 0 R >>\n"
            f"startxref\n{xref_pos}\n%%EOF\n"
        ).encode("latin-1")
        return bytes(out)


def render_pdf(report):
    """Render the compiled report to PDF bytes — zero dependencies."""
    doc = _PdfDoc()
    doc.title_block(report)

    doc.kv_grid([
        ("Case number", report["case_number"]),
        ("Status", report["status"]),
        ("Lead investigator", report["lead"]),
        ("Opened (UTC)", f"{report['opened_at']:%Y-%m-%d %H:%M}"),
        ("Evidence items", str(report["stats"]["evidence"])),
        ("Timeline events", str(report["stats"]["events"])),
        ("Findings", f"{report['stats']['findings']} ({report['stats']['high_risk']} high/critical)"),
        ("Generated", f"{report['generated_at']:%Y-%m-%d %H:%M} UTC"),
    ])

    if report["description"]:
        doc.heading(0, "Case description")
        doc.para(report["description"])

    doc.heading(1, "Executive summary")
    doc.para(report["narrative"])

    doc.heading(2, "Key findings")
    if report["findings"]:
        doc.table(
            ["Severity", "Finding / summary", "Conf.", "Technique", "Status"],
            [
                [
                    f["severity"].upper(),
                    f"{f['title']} - {f['summary']}",
                    f"{f['confidence']:.0%}",
                    f["mitre"],
                    f["status"],
                ]
                for f in report["findings"]
            ],
            [58, 240, 40, 92, 60],
        )
    else:
        doc.para("No findings recorded yet - run AI analysis to generate conclusions.")

    doc.heading(3, "Attack timeline")
    if report["events"]:
        doc.table(
            ["When (UTC)", "Event", "Sev", "Actor / source"],
            [
                [
                    f"{e['occurred_at']:%Y-%m-%d %H:%M}",
                    e["title"],
                    e["severity"].upper(),
                    f"{e['actor']} / {e['source_ip']}",
                ]
                for e in report["events"][:400]
            ],
            [88, 220, 52, 130],
        )
        if len(report["events"]) > 400:
            doc.para(f"... {len(report['events']) - 400} earlier events omitted - see the case timeline.")
    else:
        doc.para("No timeline events recorded yet.")

    doc.heading(4, "Evidence register")
    if report["evidence"]:
        doc.table(
            ["Evidence", "Type", "SHA-256 fingerprint", "Uploaded"],
            [
                [
                    e["title"],
                    e["type"],
                    e["sha256"],
                    f"{e['uploaded_at']:%Y-%m-%d} by {e['uploaded_by']}",
                ]
                for e in report["evidence"]
            ],
            [110, 66, 190, 124],
            size=7.6,
        )
    else:
        doc.para("No evidence uploaded yet.")

    doc.heading(5, "Chain of custody")
    ic = report["integrity"]
    verdict = "VERIFIED - no tampering detected" if ic["valid"] else "FAILED - tampering detected"
    pairs = [
        ("Verification result", verdict),
        ("Ledger blocks", str(ic["blocks"])),
        ("Chain tip", ic["tip"]),
        ("Checked at (UTC)", str(ic["checked_at"])),
    ]
    if ic["tampered"]:
        pairs.append((
            "Tampered objects",
            ", ".join(str(t.get("label", t.get("object_id", "?"))) for t in ic["tampered"]),
        ))
    doc.kv_grid(pairs, cols=1)

    doc.heading(6, "Sign-off")
    doc.para(
        f"This report was compiled automatically by TRACE-X from case {report['case_number']} "
        f"on {report['generated_at']:%Y-%m-%d %H:%M} UTC. Every conclusion above is traceable to "
        "the evidence register: open any finding in TRACE-X to see the exact supporting excerpts "
        "and rationale. The evidence fingerprints and hash chain quoted here can be re-verified "
        "at any time from the case's Integrity page."
    )
    doc.sign_lines(["Lead investigator", "Signature / date"])
    doc.para(
        f"TRACE-X - Evidence-to-Conclusion traceability - generated "
        f"{report['generated_at']:%Y-%m-%d %H:%M} UTC",
        size=8, color=_GREY, bold=True,
    )

    return doc.build(
        footer_left=f"TRACE-X Incident Report {report['case_number']}  -  CONFIDENTIAL"
    )
