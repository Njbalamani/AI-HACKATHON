# TRACE-X — AI-Powered Cyber Investigation Assistant

TRACE-X is a Django-based cybersecurity investigation platform that turns raw
evidence (logs, emails, IDS alerts, netflow) into **traceable conclusions**:

- **Evidence fingerprints** — every upload is hashed with SHA-256 at arrival.
- **Tamper-evident ledger** — blockchain-style append-only hash chain
  (`block_hash = SHA-256(height | timestamp | prev_hash | payload_hash)`) over
  evidence, timeline events and findings. Any unauthorized modification of
  investigation data or the ledger itself is detected.
- **Deterministic AI analysis** — parsers + detection rules + correlation
  engine reconstruct a chronological attack timeline and emit findings
  (brute force, compromise after failures, phishing, malware, C2 beaconing,
  recon scans, exfiltration, privilege escalation, cross-source IP links).
- **Evidence-to-Conclusion traceability** — every finding stores the exact
  supporting evidence, excerpts and rationale; the finding page shows the
  full trail (Finding → Evidence → raw excerpt).
- **JSON API** — `/api/investigations/`, per-case detail with traceability,
  `/analyze`, `/integrity`, plus `/api/health`.

## Quick start

```bash
pip install -r requirements.txt
python manage.py migrate
python manage.py seed_demo        # demo case TRX-0001 + user `investigator` / `tracex123`
python manage.py runserver
```

Open http://127.0.0.1:8000/ and sign in as `investigator` / `tracex123`.

Demo evidence files live in `demo/evidence/` and are loaded by `seed_demo`
(fallback content is embedded in the command if the folder is missing).

## Tests

```bash
python manage.py test
```

54 tests cover hashing, the integrity chain and tamper detection, all
parsers, detection rules, correlation, timeline ordering, finding
traceability, evidence upload & validation, UI views, the JSON API and the
complete create → upload → hash → analyze → verify → report workflow.

## Security notes

- Uploaded files are treated as untrusted data — never executed.
- Upload size limit (25 MB), safe storage filenames, login-protected views.
- Runs fully locally; no evidence leaves the machine.
